
interface Window {
  launchlist?: {
    reset?: () => void;
  };
}
